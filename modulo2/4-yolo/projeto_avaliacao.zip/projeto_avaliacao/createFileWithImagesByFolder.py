import glob2
import os
import sys
from pathlib import Path

rootPath ="/media/adriano/CC64676064674BF0/Dados/especializacao/yolov3/projeto/dataset"

jpg_files = [f for f in glob2.glob(rootPath + "/**/*.jpg", recursive=True)]
TRAIN_FILE = "./treino.txt"

with open (TRAIN_FILE, "w") as train_file:
    train_file.write("\n".join(str(item) for item in jpg_files))



    